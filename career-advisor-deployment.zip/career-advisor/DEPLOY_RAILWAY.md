# Deploy AI Student Career & Skill Advisor on Railway

This project is a Node.js + Express + MySQL web app. Railway can run the app as one service and provide a MySQL service in the same project.

## What was prepared

- `Dockerfile` for production deployment.
- `.env.example` instead of the real `.env`.
- Railway-compatible MySQL environment variables (`MYSQLHOST`, `MYSQLPORT`, `MYSQLUSER`, `MYSQLPASSWORD`, `MYSQLDATABASE`).
- `/health` endpoint for deployment health checks.
- First-start database initialization: the app automatically imports `career_advisor.sql` and `seed.sql` when the database is empty.

## Option A — Railway Dashboard

1. Create a Railway project.
2. Add a **MySQL** database service.
3. Deploy this project as a service from GitHub or upload/deploy the project with Railway CLI.
4. In the app service Variables, set:
   - `JWT_SECRET` = a new long random secret
   - `NODE_ENV` = `production`
5. The app already understands Railway's MySQL variables. If the services are in the same Railway project, use the MySQL service's variables or references for the app service:
   - `DB_HOST` = MySQL host
   - `DB_PORT` = MySQL port
   - `DB_USER` = MySQL user
   - `DB_PASS` = MySQL password
   - `DB_NAME` = MySQL database
6. Deploy the app.
7. Open the app service's Networking settings and generate a public domain.
8. Open the generated URL. The app should show the Career Advisor interface.

The first successful application start initializes the database automatically.

## Option B — Railway CLI

From this project folder:

```bash
railway login
railway init
railway add --database mysql
railway up
```

Then configure `JWT_SECRET` and, if necessary, map the MySQL service variables to the app service variables. Generate a public domain from the app service Networking settings.

## Important security note

The original ZIP contained a real `.env` file with a database password and JWT secret. Those values are intentionally NOT included in this deployment ZIP.

If those credentials are used anywhere outside your local machine, change/rotate them before production deployment.

## Database behavior

The app only runs the SQL initialization when the `users` table does not exist. It will not reset an existing database on every restart.

## Local run

```bash
npm install
copy .env.example .env
# edit .env
npm start
```

Then open:

`http://localhost:3000`

## Health check

`GET /health` returns:

```json
{"ok":true,"service":"career-advisor"}
```
